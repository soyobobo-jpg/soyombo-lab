import { useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import SoundWaveExperiment from "@/components/experiments/SoundWaveExperiment";
import OrbitalMotionExperiment from "@/components/experiments/OrbitalMotionExperiment";

import EvaporationExperiment from "@/components/experiments/EvaporationExperiment";
import StateChangeExperiment from "@/components/experiments/StateChangeExperiment";

const experiments: Record<
  string,
  {
    title: string;
    description: string;
    component: React.ComponentType;
    fullDescription: string;
  }
> = {
  sound_wave: {
    title: "Дууны долгион",
    description: "Дууны долгионы шинж чанарыг судлаарай",
    component: SoundWaveExperiment,
    fullDescription:
      "Дуу нь механик долгион бөгөөд орчны дундаар тархдаг. Энэ туршилтаар давтамж (дууны өндөр) болон далайц (дууны чанар) нь дууны долгионд хэрхэн нөлөөлөхийг харж болно. Хяналтуудыг өөрчилж, өөр өөр давтамжийн долгионы хэлбэрийг ажиглаарай.",
  },
  orbital_motion: {
    title: "Тойрог замын хөдөлгөөн",
    description: "Гаригуудын тойрог замын хөдөлгөөнийг ойлгоорой",
    component: OrbitalMotionExperiment,
    fullDescription:
      "Сансрын объектууд массив биеийн эргэн тойронд таталцлын хүчний улмаас тойрог замаар хөдөлдөг. Энэ симуляторт тойрог замын хурд болон радиусын хамаарлыг харж болно. Ягаан вектор нь хурдны чиглэлийг харуулдаг бөгөөд энэ нь радиусын перпендикуляр байдаг.",
  },

  evaporation: {
    title: "Ууршилт",
    description: "Шингэний ууршилтын үйл явцыг судлаарай",
    component: EvaporationExperiment,
    fullDescription:
      "Ууршилт нь шингэнээс уур болж хувирах үйл явц юм. Температур болон даралт нь ууршилтын хурдад нөлөөлдөг. Энэ туршилтаар эдгээр хүчин зүйлсийн нөлөөллийг ажиглаж болно.",
  },
  state_change: {
    title: "Төлөвийн өөрчлөлт",
    description: "Хатуу, шингэн, хийн төлөвүүдийг судлаарай",
    component: StateChangeExperiment,
    fullDescription:
      "Бүх бодис гурван төлөвтэй байдаг: хатуу, шингэн, хий. Температур нэмэгдэхэд молекулуудын кинетик энерги нэмэгдэж, төлөв өөрчлөгддөг. Энэ туршилтаар температурын нөлөөллийг шууд ажиглаж болно.",
  },
};

export default function ExperimentDetail() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();

  if (!id || !experiments[id]) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-display font-bold mb-4">
            Туршилт олдсонгүй
          </h1>
          <Button
            onClick={() => navigate("/")}
            className="bg-cyan-500 hover:bg-cyan-600"
          >
            Үндсэн хуудас руу
          </Button>
        </div>
      </div>
    );
  }

  const experiment = experiments[id];
  const Component = experiment.component;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-cyan-500/20">
        <div className="container mx-auto px-4 py-4 flex items-center gap-4">
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            className="border-cyan-500/30 hover:bg-cyan-500/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Буцах
          </Button>
          <h1 className="text-2xl font-display font-bold text-cyan-300">
            {experiment.title}
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main experiment */}
          <div className="lg:col-span-2">
            <Component />
          </div>

          {/* Sidebar info */}
          <div className="space-y-6">
            {/* Description */}
            <div className="bg-card/50 border border-cyan-500/20 rounded-lg p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-cyan-300 mb-3">
                Энэ туршилтын тухай
              </h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {experiment.fullDescription}
              </p>
            </div>

            {/* Learning objectives */}
            <div className="bg-card/50 border border-cyan-500/20 rounded-lg p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-purple-300 mb-3">
                Сургалтын зорилго
              </h2>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li className="flex gap-2">
                  <span className="text-cyan-400">•</span>
                  <span>Физик, химийн үндсэн ойлголтуудыг ойлгох</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400">•</span>
                  <span>Хийсвэ ойлголтуудыг дүрслэлээр харуулах</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-cyan-400">•</span>
                  <span>Шалтгаан болон үр дүнгийн хамаарлыг судлах</span>
                </li>
              </ul>
            </div>

            {/* Tips */}
            <div className="bg-card/50 border border-orange-500/20 rounded-lg p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-orange-300 mb-3">
                Сургалтын зөвлөмж
              </h2>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li className="flex gap-2">
                  <span className="text-orange-400">→</span>
                  <span>Туйлын утгуудыг сорьж, хязгаарыг харах</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-orange-400">→</span>
                  <span>Хэргүүдийн хэв маяг, хамаарлыг ажиглах</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-orange-400">→</span>
                  <span>Утгуудыг өөрчилөхөөс өмнө урьдчилсан таамаглал гаргах</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
