import { useState } from "react";
import ExperimentCard from "@/components/ExperimentCard";
import { Zap, Radio, Orbit } from "lucide-react";

export default function Home() {
  const experiments = [
    {
      id: "sound_wave",
      title: "Дууны долгион",
      description:
        "Дууны долгионы шинж чанарыг судлаарай. Давтамж болон далайцыг өөрчилж, дууны өндөр, чанарын хамаарлыг харуулаарай.",
      icon: <Radio className="w-8 h-8" />,
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663571761960/CDnpcj7xTZXB3CQN5nmzqx/sound-wave-viz-XfVdzjMkAUtzYyAoahha7q.webp",
    },
    {
      id: "orbital_motion",
      title: "Тойрог замын хөдөлгөөн",
      description:
        "Гаригуудын тойрог замын хөдөлгөөн, таталцлын хүчийг ойлгоорой. Масс болон хурдны нөлөөллийг харуулаарай.",
      icon: <Orbit className="w-8 h-8" />,
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663571761960/CDnpcj7xTZXB3CQN5nmzqx/orbital-motion-2ZP5SsjYP6gzMm47pdBhvX.webp",
    },
    {
      id: "evaporation",
      title: "Ууршилт",
      description:
        "Шингэний ууршилтын үйл явцыг судлаарай. Температур, даралтын нөлөөллийг ажиглаарай.",
      icon: <Zap className="w-8 h-8" />,
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663571761960/CDnpcj7xTZXB3CQN5nmzqx/energy-transfer-a8D4SKXa6F77mj2HtzTaQa.webp",
    },
    {
      id: "state_change",
      title: "Төлөвийн өөрчлөлт",
      description:
        "Хатуу, шингэн, хийн төлөвүүдийн хамаарлыг судлаарай. Температурын нөлөөллийг ажиглаарай.",
      icon: <Zap className="w-8 h-8" />,
      image:
        "https://d2xsxph8kpxj0f.cloudfront.net/310519663571761960/CDnpcj7xTZXB3CQN5nmzqx/energy-transfer-a8D4SKXa6F77mj2HtzTaQa.webp",
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        {/* Background image */}
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663571761960/CDnpcj7xTZXB3CQN5nmzqx/hero-particles-DBAeXjzYvRUuuEkKkobJhs.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/70 to-background" />

        {/* Content */}
        <div className="relative container mx-auto px-4 py-20 text-center">
          <div className="animate-slide-in">
            <h1 className="text-5xl md:text-6xl font-display font-bold mb-6 bg-gradient-to-r from-cyan-300 via-purple-300 to-orange-300 bg-clip-text text-transparent">
              Soyombo Lab
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Сурагчдад зориулсан интерактив физик & химийн туршилтууд
            </p>
            <p className="text-base text-muted-foreground max-w-3xl mx-auto mb-8">
              Физик, химийн үндсэн ойлголтуудыг интерактив дүрслэлээр судлаарай. Дууны долгион, тойрог замын хөдөлгөөн, химийн урвалаас эхлэн ертөнцийн нууцыг нээж авч үзээрэй.
            </p>
          </div>
        </div>
      </div>

      {/* Experiments Section */}
      <div className="container mx-auto px-4 py-16">
        {/* Experiments grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {experiments.map((experiment, index) => (
            <div
              key={experiment.id}
              style={{
                animation: `slide-in 0.6s ease-out ${index * 0.1}s both`,
              }}
            >
              <ExperimentCard {...experiment} />
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="bg-background/50 border-t border-cyan-500/20 py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Soyombo Lab © 2026 - Интерактив физик & химийн туршилтууд
          </p>
        </div>
      </div>
    </div>
  );
}
