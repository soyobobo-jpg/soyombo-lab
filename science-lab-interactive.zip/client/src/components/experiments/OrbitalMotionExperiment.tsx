import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw } from "lucide-react";

export default function OrbitalMotionExperiment() {
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [mass, setMass] = useState(50);
  const [angle, setAngle] = useState(0);

  // Simulate orbital motion
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setAngle((prev) => (prev + speed * 0.5) % 360);
    }, 30);

    return () => clearInterval(interval);
  }, [isRunning, speed]);

  const handleReset = () => {
    setAngle(0);
    setIsRunning(false);
  };

  // Calculate orbital radius based on mass (simulating gravity)
  const radius = 80 + (mass / 100) * 20;

  // Calculate planet position
  const radians = (angle * Math.PI) / 180;
  const planetX = 150 + radius * Math.cos(radians);
  const planetY = 150 + radius * Math.sin(radians);

  // Calculate velocity vector
  const velocityScale = 30;
  const velocityX = -Math.sin(radians) * velocityScale;
  const velocityY = Math.cos(radians) * velocityScale;

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card/50 border-cyan-500/20">
        <h2 className="text-2xl font-display font-bold text-cyan-300 mb-6">
          Тойрог замын хөдөлгөөн симулятор
        </h2>

        {/* Orbital visualization */}
        <div className="bg-background/50 rounded-lg p-4 mb-6 border border-cyan-500/20">
          <svg
            viewBox="0 0 300 300"
            className="w-full h-80 bg-gradient-to-br from-background to-background/50 rounded"
          >
            {/* Star/Sun at center */}
            <circle
              cx="150"
              cy="150"
              r="8"
              fill="#fbbf24"
              className="drop-shadow-lg"
            />
            <circle
              cx="150"
              cy="150"
              r="15"
              fill="#fbbf24"
              opacity="0.3"
            />

            {/* Orbital path */}
            <circle
              cx="150"
              cy="150"
              r={radius}
              fill="none"
              stroke="rgba(0, 212, 255, 0.2)"
              strokeWidth="1"
              strokeDasharray="5,5"
            />

            {/* Orbital path glow */}
            <circle
              cx="150"
              cy="150"
              r={radius}
              fill="none"
              stroke="rgba(0, 212, 255, 0.1)"
              strokeWidth="3"
            />

            {/* Planet */}
            <circle
              cx={planetX}
              cy={planetY}
              r="6"
              fill="#00d4ff"
              className="drop-shadow-lg"
            />
            <circle
              cx={planetX}
              cy={planetY}
              r="12"
              fill="#00d4ff"
              opacity="0.3"
            />

            {/* Velocity vector */}
            <line
              x1={planetX}
              y1={planetY}
              x2={planetX + velocityX}
              y2={planetY + velocityY}
              stroke="#7c3aed"
              strokeWidth="2"
              markerEnd="url(#arrowhead)"
            />

            {/* Arrow marker definition */}
            <defs>
              <marker
                id="arrowhead"
                markerWidth="10"
                markerHeight="10"
                refX="9"
                refY="3"
                orient="auto"
              >
                <polygon points="0 0, 10 3, 0 6" fill="#7c3aed" />
              </marker>
            </defs>

            {/* Radius line */}
            <line
              x1="150"
              y1="150"
              x2={planetX}
              y2={planetY}
              stroke="rgba(255, 107, 53, 0.3)"
              strokeWidth="1"
              strokeDasharray="3,3"
            />

            {/* Info labels */}
            <text
              x="150"
              y="280"
              textAnchor="middle"
              fill="rgba(248, 249, 250, 0.6)"
              fontSize="12"
            >
              Өнцөг: {angle.toFixed(0)}°
            </text>
          </svg>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          {/* Speed control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-semibold text-foreground">
                Тойрог замын хурд
              </label>
              <span className="text-cyan-400 font-mono font-bold">
                {speed.toFixed(1)}x
              </span>
            </div>
            <Slider
              value={[speed]}
              onValueChange={(value) => setSpeed(value[0])}
              min={0.1}
              max={3}
              step={0.1}
              className="w-full"
            />
          </div>

          {/* Mass control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-semibold text-foreground">
                Тойрог замын радиус (Масс)
              </label>
              <span className="text-purple-400 font-mono font-bold">
                {mass}%
              </span>
            </div>
            <Slider
              value={[mass]}
              onValueChange={(value) => setMass(value[0])}
              min={10}
              max={100}
              step={5}
              className="w-full"
            />
          </div>

          {/* Control buttons */}
          <div className="flex gap-3">
            <Button
              onClick={() => setIsRunning(!isRunning)}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  Зогсоох
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Эхлүүлэх
                </>
              )}
            </Button>
            <Button
              onClick={handleReset}
              className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Дахин эхлүүлэх
            </Button>
          </div>
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-background/50 rounded-lg border border-cyan-500/10">
          <p className="text-sm text-muted-foreground">
            Энэ симуляцион нь объектууд төвийн биеийн эргэн тойронд хэрхэн тойрог замаар хөдөлдөгийг харуулдаг. 
            <span className="text-cyan-300 font-semibold"> Ягаан вектор</span> нь хурдны чиглэлийг харуулдаг. 
            Тойрог замын радиусыг өөрчилж, масс нь тойрог замын механикт хэрхэн нөлөөлөхийг ажиглаарай.
          </p>
        </div>
      </Card>
    </div>
  );
}
