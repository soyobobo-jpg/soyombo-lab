import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Thermometer } from "lucide-react";

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
}

export default function StateChangeExperiment() {
  const [temperature, setTemperature] = useState(20);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [state, setState] = useState<"solid" | "liquid" | "gas">("solid");
  const [animationFrame, setAnimationFrame] = useState(0);

  // Determine state based on temperature
  const getState = (temp: number): "solid" | "liquid" | "gas" => {
    if (temp < 0) return "solid";
    if (temp < 100) return "liquid";
    return "gas";
  };

  // Update particles based on temperature
  const updateParticles = (temp: number) => {
    const newState = getState(temp);
    setState(newState);

    let newParticles: Particle[] = [];

    if (newState === "solid") {
      // Solid: Fixed grid pattern with slight vibration
      const gridSize = 6;
      for (let i = 0; i < gridSize; i++) {
        for (let j = 0; j < gridSize; j++) {
          newParticles.push({
            id: i * gridSize + j,
            x: 80 + i * 20 + (Math.random() - 0.5) * 2,
            y: 80 + j * 20 + (Math.random() - 0.5) * 2,
            vx: (Math.random() - 0.5) * (temp / 50),
            vy: (Math.random() - 0.5) * (temp / 50),
          });
        }
      }
    } else if (newState === "liquid") {
      // Liquid: Random positions with moderate motion
      const count = 40;
      for (let i = 0; i < count; i++) {
        newParticles.push({
          id: i,
          x: 50 + Math.random() * 100,
          y: 100 + Math.random() * 80,
          vx: (Math.random() - 0.5) * ((temp - 0) / 50),
          vy: (Math.random() - 0.5) * ((temp - 0) / 50),
        });
      }
    } else {
      // Gas: Highly dispersed with high velocity
      const count = 60;
      for (let i = 0; i < count; i++) {
        const angle = (Math.random() * Math.PI * 2);
        const speed = 2 + ((temp - 100) / 100) * 4;
        newParticles.push({
          id: i,
          x: 150 + (Math.random() - 0.5) * 40,
          y: 150 + (Math.random() - 0.5) * 40,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
        });
      }
    }

    setParticles(newParticles);
  };

  // Animate particles
  const handleTemperatureChange = (value: number) => {
    setTemperature(value);
    updateParticles(value);

    // Animate gas particles
    if (getState(value) === "gas") {
      let frame = 0;
      const animate = () => {
        frame++;
        setAnimationFrame(frame);

        setParticles((prev) =>
          prev.map((p) => {
            let newP = { ...p };
            newP.x += newP.vx;
            newP.y += newP.vy;

            // Bounce off walls
            if (newP.x < 35) {
              newP.x = 35;
              newP.vx *= -1;
            }
            if (newP.x > 265) {
              newP.x = 265;
              newP.vx *= -1;
            }
            if (newP.y < 35) {
              newP.y = 35;
              newP.vy *= -1;
            }
            if (newP.y > 265) {
              newP.y = 265;
              newP.vy *= -1;
            }

            return newP;
          })
        );

        if (frame < 200) {
          requestAnimationFrame(animate);
        }
      };
      animate();
    }
  };

  const getStateLabel = (s: "solid" | "liquid" | "gas") => {
    switch (s) {
      case "solid":
        return "Хатуу";
      case "liquid":
        return "Шингэн";
      case "gas":
        return "Хий";
    }
  };

  const getStateColor = (s: "solid" | "liquid" | "gas") => {
    switch (s) {
      case "solid":
        return "#00d4ff";
      case "liquid":
        return "#7c3aed";
      case "gas":
        return "#ff6b35";
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card/50 border-cyan-500/20">
        <h2 className="text-2xl font-display font-bold text-cyan-300 mb-6">
          Төлөвийн өөрчлөлт (Хатуу → Шингэн → Хий)
        </h2>

        {/* State visualization */}
        <div className="bg-background/50 rounded-lg p-4 mb-6 border border-cyan-500/20">
          <svg
            viewBox="0 0 300 300"
            className="w-full h-80 bg-gradient-to-br from-background to-background/50 rounded"
          >
            {/* Container */}
            <rect
              x="30"
              y="30"
              width="240"
              height="240"
              fill="none"
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="2"
              rx="5"
            />

            {/* Background based on state */}
            {state === "solid" && (
              <rect
                x="30"
                y="30"
                width="240"
                height="240"
                fill="rgba(0, 212, 255, 0.05)"
              />
            )}
            {state === "liquid" && (
              <rect
                x="30"
                y="120"
                width="240"
                height="150"
                fill="rgba(124, 58, 237, 0.05)"
              />
            )}
            {state === "gas" && (
              <rect
                x="30"
                y="30"
                width="240"
                height="240"
                fill="rgba(255, 107, 53, 0.03)"
              />
            )}

            {/* Particles */}
            {particles.map((p) => {
              // Keep particles within bounds
              let displayX = p.x;
              let displayY = p.y;

              if (state === "liquid") {
                displayX = Math.max(40, Math.min(260, p.x));
                displayY = Math.max(120, Math.min(260, p.y));
              } else if (state === "gas") {
                displayX = Math.max(35, Math.min(265, p.x));
                displayY = Math.max(35, Math.min(265, p.y));
              }

              return (
                <circle
                  key={p.id}
                  cx={displayX}
                  cy={displayY}
                  r={state === "solid" ? 3 : state === "liquid" ? 2.5 : 2}
                  fill={getStateColor(state)}
                  opacity={state === "gas" ? 0.7 : 0.85}
                />
              );
            })}

            {/* State label */}
            <text
              x="150"
              y="290"
              textAnchor="middle"
              fill={getStateColor(state)}
              fontSize="14"
              fontWeight="bold"
            >
              {getStateLabel(state)}
            </text>
          </svg>
        </div>

        {/* Temperature control */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2">
              <Thermometer className="w-5 h-5 text-orange-400" />
              <label className="text-sm font-semibold text-foreground">
                Температур
              </label>
            </div>
            <span className="text-orange-400 font-mono font-bold text-lg">
              {temperature}°C
            </span>
          </div>
          <Slider
            value={[temperature]}
            onValueChange={(value) => handleTemperatureChange(value[0])}
            min={-50}
            max={200}
            step={1}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>-50°C (Хатуу)</span>
            <span>0°C</span>
            <span>100°C</span>
            <span>200°C (Хий)</span>
          </div>
        </div>

        {/* State transition indicators */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div
            className={`p-3 rounded-lg border text-center transition-all duration-300 ${
              state === "solid"
                ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-300"
                : "bg-background/50 border-cyan-500/20 text-muted-foreground"
            }`}
          >
            <p className="text-xs font-semibold">Хатуу</p>
            <p className="text-xs mt-1">(-50 ~ 0°C)</p>
          </div>
          <div
            className={`p-3 rounded-lg border text-center transition-all duration-300 ${
              state === "liquid"
                ? "bg-purple-500/20 border-purple-500/50 text-purple-300"
                : "bg-background/50 border-cyan-500/20 text-muted-foreground"
            }`}
          >
            <p className="text-xs font-semibold">Шингэн</p>
            <p className="text-xs mt-1">(0 ~ 100°C)</p>
          </div>
          <div
            className={`p-3 rounded-lg border text-center transition-all duration-300 ${
              state === "gas"
                ? "bg-orange-500/20 border-orange-500/50 text-orange-300"
                : "bg-background/50 border-cyan-500/20 text-muted-foreground"
            }`}
          >
            <p className="text-xs font-semibold">Хий</p>
            <p className="text-xs mt-1">(100 ~ 200°C)</p>
          </div>
        </div>

        {/* Info */}
        <div className="p-4 bg-background/50 rounded-lg border border-cyan-500/10 space-y-3">
          <p className="text-sm text-muted-foreground">
            <span className="text-cyan-300 font-semibold">Хатуу төлөв:</span> Молекулууд нь тогтмол байрлалд байх бөгөөд зөвхөн чичирдэг. Хатуу биетүүд тодорхой хэлбэр, эзэлхүүнтэй байдаг.
          </p>
          <p className="text-sm text-muted-foreground">
            <span className="text-purple-300 font-semibold">Шингэн төлөв:</span> Молекулууд нь хөдлөх чөлөө байх бөгөөд хоорондоо холбоотой байдаг. Шингэнүүд эзэлхүүн нь тогтмол боловч хэлбэр нь сав хэлбэрээр өөрчлөгддөг.
          </p>
          <p className="text-sm text-muted-foreground">
            <span className="text-orange-300 font-semibold">Хий төлөв:</span> Молекулууд нь сул холбоотой бөгөөд хурдан хөдөлдөг, бүх чиглэлд сарниж явдаг. Хийүүд эзэлхүүн, хэлбэр нь сав хэлбэрээр өөрчлөгддөг.
          </p>
        </div>
      </Card>
    </div>
  );
}
