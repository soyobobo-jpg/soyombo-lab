import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Play, Pause, RotateCcw } from "lucide-react";

interface Molecule {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  inLiquid: boolean;
}

export default function EvaporationExperiment() {
  const [isRunning, setIsRunning] = useState(false);
  const [temperature, setTemperature] = useState(30);
  const [pressure, setPressure] = useState(50);
  const [molecules, setMolecules] = useState<Molecule[]>([]);
  const [evaporatedCount, setEvaporatedCount] = useState(0);
  const [animationFrame, setAnimationFrame] = useState(0);

  // Initialize molecules
  useEffect(() => {
    const newMolecules: Molecule[] = [];
    for (let i = 0; i < 50; i++) {
      newMolecules.push({
        id: i,
        x: 50 + Math.random() * 100,
        y: 200 + Math.random() * 50,
        vx: (Math.random() - 0.5) * 1,
        vy: (Math.random() - 0.5) * 1,
        inLiquid: true,
      });
    }
    setMolecules(newMolecules);
    setEvaporatedCount(0);
  }, []);

  // Simulate evaporation
  useEffect(() => {
    if (!isRunning || molecules.length === 0) return;

    let frameCount = 0;
    const interval = setInterval(() => {
      frameCount++;
      setAnimationFrame(frameCount);

      setMolecules((prev) => {
        let evaporated = 0;
        const tempFactor = temperature / 100;
        const pressureFactor = pressure / 100;

        const updated = prev.map((mol) => {
          let newMol = { ...mol };

          if (newMol.inLiquid) {
            // Add random motion based on temperature
            newMol.vx += (Math.random() - 0.5) * tempFactor * 0.8;
            newMol.vy += (Math.random() - 0.5) * tempFactor * 0.8;

            // Limit velocity
            const maxVel = tempFactor * 3;
            const vel = Math.sqrt(newMol.vx ** 2 + newMol.vy ** 2);
            if (vel > maxVel) {
              newMol.vx = (newMol.vx / vel) * maxVel;
              newMol.vy = (newMol.vy / vel) * maxVel;
            }

            // Move molecule
            newMol.x += newMol.vx;
            newMol.y += newMol.vy;

            // Boundary conditions for liquid
            if (newMol.x < 30) newMol.x = 30;
            if (newMol.x > 270) newMol.x = 270;
            if (newMol.y > 220) {
              newMol.y = 220;
              newMol.vy *= -0.5;
            }

            // Check if molecule escapes (evaporates)
            const escapeThreshold = 160 - temperature * 0.5 - pressure * 0.2;
            if (newMol.y < escapeThreshold) {
              if (Math.random() < tempFactor * 0.15 * (1 - pressureFactor * 0.5)) {
                newMol.inLiquid = false;
                evaporated++;
              }
            }
          } else {
            // Molecules in vapor phase
            newMol.y -= 1 + tempFactor * 0.5;
            newMol.x += newMol.vx * 0.3;
            newMol.vx *= 0.98;

            // Pressure pulls molecules back down
            if (Math.random() < pressureFactor * 0.05) {
              newMol.vy += 0.1;
            }
          }

          return newMol;
        });

        if (evaporated > 0) {
          setEvaporatedCount((prev) => prev + evaporated);
        }

        return updated;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isRunning, temperature, pressure, molecules.length]);

  const handleReset = () => {
    setIsRunning(false);
    setEvaporatedCount(0);
    setAnimationFrame(0);
    const newMolecules: Molecule[] = [];
    for (let i = 0; i < 50; i++) {
      newMolecules.push({
        id: i,
        x: 50 + Math.random() * 100,
        y: 200 + Math.random() * 50,
        vx: (Math.random() - 0.5) * 1,
        vy: (Math.random() - 0.5) * 1,
        inLiquid: true,
      });
    }
    setMolecules(newMolecules);
  };

  const liquidMolecules = molecules.filter((m) => m.inLiquid);
  const vaporMolecules = molecules.filter((m) => !m.inLiquid);

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card/50 border-cyan-500/20">
        <h2 className="text-2xl font-display font-bold text-cyan-300 mb-6">
          Ууршилтын туршилт
        </h2>

        {/* Evaporation visualization */}
        <div className="bg-background/50 rounded-lg p-4 mb-6 border border-cyan-500/20">
          <svg
            viewBox="0 0 300 300"
            className="w-full h-80 bg-gradient-to-b from-background to-background/50 rounded"
          >
            {/* Container */}
            <rect
              x="30"
              y="30"
              width="240"
              height="240"
              fill="none"
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="2"
              rx="5"
            />

            {/* Liquid level indicator */}
            <line
              x1="30"
              y1="180"
              x2="270"
              y2="180"
              stroke="rgba(0, 212, 255, 0.2)"
              strokeWidth="1"
              strokeDasharray="5,5"
            />

            {/* Liquid region background */}
            <rect
              x="30"
              y="180"
              width="240"
              height="90"
              fill="rgba(0, 212, 255, 0.05)"
            />

            {/* Liquid molecules */}
            {liquidMolecules.map((mol) => (
              <circle
                key={`liquid-${mol.id}`}
                cx={mol.x}
                cy={mol.y}
                r="3"
                fill="#00d4ff"
                opacity="0.9"
              />
            ))}

            {/* Vapor molecules */}
            {vaporMolecules.map((mol) => (
              <circle
                key={`vapor-${mol.id}`}
                cx={mol.x}
                cy={Math.max(30, mol.y)}
                r="2.5"
                fill="#7c3aed"
                opacity="0.7"
              />
            ))}

            {/* Heat indicator */}
            {isRunning && temperature > 20 && (
              <>
                <circle
                  cx="150"
                  cy="250"
                  r={3 + (temperature / 100) * 8}
                  fill="none"
                  stroke="#ff6b35"
                  strokeWidth="1"
                  opacity={0.4}
                />
                <text
                  x="150"
                  y="255"
                  textAnchor="middle"
                  fill="#ff6b35"
                  fontSize="14"
                >
                  🔥
                </text>
              </>
            )}

            {/* Labels */}
            <text
              x="150"
              y="25"
              textAnchor="middle"
              fill="rgba(248, 249, 250, 0.6)"
              fontSize="12"
              fontWeight="bold"
            >
              Уур ({vaporMolecules.length})
            </text>
            <text
              x="150"
              y="290"
              textAnchor="middle"
              fill="rgba(248, 249, 250, 0.6)"
              fontSize="12"
              fontWeight="bold"
            >
              Шингэн ({liquidMolecules.length})
            </text>
          </svg>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-background/50 rounded-lg p-4 border border-cyan-500/20">
            <p className="text-xs text-muted-foreground mb-1">Шингэнийн молекулууд</p>
            <p className="text-2xl font-bold text-cyan-400">{liquidMolecules.length}</p>
          </div>
          <div className="bg-background/50 rounded-lg p-4 border border-purple-500/20">
            <p className="text-xs text-muted-foreground mb-1">Уурын молекулууд</p>
            <p className="text-2xl font-bold text-purple-400">{vaporMolecules.length}</p>
          </div>
          <div className="bg-background/50 rounded-lg p-4 border border-orange-500/20">
            <p className="text-xs text-muted-foreground mb-1">Нийт ууршилт</p>
            <p className="text-2xl font-bold text-orange-400">{evaporatedCount}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          {/* Temperature control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-semibold text-foreground">
                Температур
              </label>
              <span className="text-orange-400 font-mono font-bold">
                {temperature}°C
              </span>
            </div>
            <Slider
              value={[temperature]}
              onValueChange={(value) => setTemperature(value[0])}
              min={0}
              max={100}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>0°C</span>
              <span>100°C</span>
            </div>
          </div>

          {/* Pressure control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-semibold text-foreground">
                Даралт
              </label>
              <span className="text-purple-400 font-mono font-bold">
                {pressure}%
              </span>
            </div>
            <Slider
              value={[pressure]}
              onValueChange={(value) => setPressure(value[0])}
              min={0}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          {/* Control buttons */}
          <div className="flex gap-3">
            <Button
              onClick={() => setIsRunning(!isRunning)}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  Зогсоох
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Эхлүүлэх
                </>
              )}
            </Button>
            <Button
              onClick={handleReset}
              className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Дахин эхлүүлэх
            </Button>
          </div>
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-background/50 rounded-lg border border-cyan-500/10">
          <p className="text-sm text-muted-foreground">
            <span className="text-cyan-300 font-semibold">Ууршилт</span> нь шингэнээс уур болж хувирах үйл явц юм. 
            <span className="text-orange-300 font-semibold"> Температур</span> нэмэгдэхэд молекулуудын кинетик энерги нэмэгдэж, ууршилт хурдан явагдана. 
            <span className="text-purple-300 font-semibold"> Даралт</span> нь молекулуудыг шингэнд барьдаг хүч юм. Даралт нэмэгдэхэд ууршилт удаан явагдана.
          </p>
        </div>
      </Card>
    </div>
  );
}
