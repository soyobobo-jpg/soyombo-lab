import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Play, Pause } from "lucide-react";

export default function SoundWaveExperiment() {
  const [frequency, setFrequency] = useState(440); // A4 note
  const [amplitude, setAmplitude] = useState(50);
  const [isPlaying, setIsPlaying] = useState(false);
  const [waveData, setWaveData] = useState<number[]>([]);

  // Generate wave data for visualization
  useEffect(() => {
    const points = 200;
    const newData = [];
    for (let i = 0; i < points; i++) {
      const x = (i / points) * Math.PI * 4;
      const y = Math.sin(x * (frequency / 440)) * (amplitude / 100);
      newData.push(y);
    }
    setWaveData(newData);
  }, [frequency, amplitude]);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    // In a real implementation, this would play actual audio
    if (!isPlaying) {
      // Play sound
      const audioContext = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = frequency;
      oscillator.type = "sine";
      gainNode.gain.setValueAtTime(amplitude / 200, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(
        0.01,
        audioContext.currentTime + 1
      );

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 1);
    }
  };

  const maxY = Math.max(...waveData.map(Math.abs), 1);
  const scale = 100 / maxY;

  // Frequency label
  const getFrequencyLabel = (freq: number) => {
    if (freq < 20) return "Хэт доод (Infrasound)";
    if (freq < 100) return "Доод давтамж";
    if (freq < 1000) return "Дунд давтамж";
    if (freq < 10000) return "Өндөр давтамж";
    return "Хэт өндөр (Ultrasound)";
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card/50 border-cyan-500/20">
        <h2 className="text-2xl font-display font-bold text-cyan-300 mb-6">
          Дууны долгион дүрслэл
        </h2>

        {/* Wave visualization */}
        <div className="bg-background/50 rounded-lg p-4 mb-6 border border-cyan-500/20">
          <svg
            viewBox="0 0 400 200"
            className="w-full h-48 text-cyan-400"
            preserveAspectRatio="none"
          >
            {/* Grid lines */}
            {[0, 1, 2, 3, 4].map((i) => (
              <line
                key={`grid-${i}`}
                x1={(i * 100).toString()}
                y1="0"
                x2={(i * 100).toString()}
                y2="200"
                stroke="rgba(0, 212, 255, 0.1)"
                strokeWidth="1"
              />
            ))}
            {[0, 1].map((i) => (
              <line
                key={`hgrid-${i}`}
                x1="0"
                y1={(i * 200).toString()}
                x2="400"
                y2={(i * 200).toString()}
                stroke="rgba(0, 212, 255, 0.1)"
                strokeWidth="1"
              />
            ))}

            {/* Center line */}
            <line
              x1="0"
              y1="100"
              x2="400"
              y2="100"
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="1"
              strokeDasharray="5,5"
            />

            {/* Wave path */}
            <polyline
              points={waveData
                .map(
                  (y, i) =>
                    `${(i / waveData.length) * 400},${100 - y * scale * 80}`
                )
                .join(" ")}
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              vectorEffect="non-scaling-stroke"
            />

            {/* Glowing effect */}
            <polyline
              points={waveData
                .map(
                  (y, i) =>
                    `${(i / waveData.length) * 400},${100 - y * scale * 80}`
                )
                .join(" ")}
              fill="none"
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="4"
              vectorEffect="non-scaling-stroke"
              opacity="0.5"
            />
          </svg>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          {/* Frequency control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <div>
                <label className="text-sm font-semibold text-foreground block">
                  Давтамж (Hz)
                </label>
                <p className="text-xs text-muted-foreground mt-1">
                  {getFrequencyLabel(frequency)}
                </p>
              </div>
              <span className="text-cyan-400 font-mono font-bold">
                {frequency.toLocaleString()}
              </span>
            </div>
            <Slider
              value={[frequency]}
              onValueChange={(value) => setFrequency(value[0])}
              min={20}
              max={20000}
              step={10}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>20 Hz</span>
              <span>20,000 Hz</span>
            </div>
          </div>

          {/* Amplitude control */}
          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-semibold text-foreground">
                Далайц (Чанар)
              </label>
              <span className="text-purple-400 font-mono font-bold">
                {amplitude}%
              </span>
            </div>
            <Slider
              value={[amplitude]}
              onValueChange={(value) => setAmplitude(value[0])}
              min={0}
              max={100}
              step={1}
              className="w-full"
            />
          </div>

          {/* Play button */}
          <Button
            onClick={handlePlayPause}
            className="w-full bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4" />
                Дуу зогсоох
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Дуу сонсох
              </>
            )}
          </Button>
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-background/50 rounded-lg border border-cyan-500/10">
          <p className="text-sm text-muted-foreground">
            <span className="text-cyan-300 font-semibold">Давтамж</span> нь нэг секундэд давтагдах долгионы тоо (Hz). Өндөр давтамж нь өндөр дуу гаргадаг. 
            <span className="text-purple-300 font-semibold"> Далайц</span> нь долгионы өндөр бөгөөд дууны чанарыг тодорхойлдог.
            <br />
            <br />
            <strong>Давтамжийн хүрээ:</strong>
            <br />
            • 20-100 Hz: Доод давтамж (бас)
            <br />
            • 100-1000 Hz: Дунд давтамж
            <br />
            • 1000-20,000 Hz: Өндөр давтамж
          </p>
        </div>
      </Card>
    </div>
  );
}
