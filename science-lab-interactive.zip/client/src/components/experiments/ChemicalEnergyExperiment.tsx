import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Zap, RotateCcw } from "lucide-react";

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
}

export default function ChemicalEnergyExperiment() {
  const [isReacting, setIsReacting] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [energy, setEnergy] = useState(0);

  const handleReaction = () => {
    setIsReacting(true);
    setEnergy(100);

    // Create particles for reaction - more dispersed
    const newParticles: Particle[] = [];
    for (let i = 0; i < 50; i++) {
      const angle = (Math.random() * Math.PI * 2);
      const speed = 3 + Math.random() * 5;
      newParticles.push({
        id: i,
        x: 150,
        y: 150,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color: ["#00d4ff", "#7c3aed", "#ff6b35"][Math.floor(Math.random() * 3)],
        size: 2 + Math.random() * 3,
      });
    }
    setParticles(newParticles);

    // Animate particles with better dispersion
    let frame = 0;
    const animate = () => {
      frame++;
      setParticles((prev) =>
        prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx,
            y: p.y + p.vy,
            vy: p.vy + 0.08, // gravity
            vx: p.vx * 0.98, // air resistance
          }))
          .filter((p) => p.y < 320 && p.x > 20 && p.x < 280)
      );

      setEnergy((prev) => Math.max(0, prev - 1.5));

      if (frame < 120 && newParticles.length > 0) {
        requestAnimationFrame(animate);
      } else {
        setIsReacting(false);
        setParticles([]);
      }
    };

    animate();
  };

  const handleReset = () => {
    setIsReacting(false);
    setParticles([]);
    setEnergy(0);
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-card/50 border-cyan-500/20">
        <h2 className="text-2xl font-display font-bold text-cyan-300 mb-6">
          Химийн энергийн урвал
        </h2>

        {/* Reaction visualization */}
        <div className="bg-background/50 rounded-lg p-4 mb-6 border border-cyan-500/20 relative overflow-hidden">
          <svg
            viewBox="0 0 300 320"
            className="w-full h-80 bg-gradient-to-br from-background to-background/50 rounded"
          >
            {/* Container */}
            <rect
              x="30"
              y="30"
              width="240"
              height="240"
              fill="none"
              stroke="rgba(0, 212, 255, 0.3)"
              strokeWidth="2"
              rx="10"
            />

            {/* Reactants (before reaction) */}
            {!isReacting && particles.length === 0 && (
              <>
                {/* Molecule 1 - Cyan and Purple */}
                <circle cx="80" cy="100" r="7" fill="#00d4ff" opacity="0.9" />
                <circle cx="95" cy="100" r="7" fill="#7c3aed" opacity="0.9" />
                <line
                  x1="87"
                  y1="100"
                  x2="88"
                  y2="100"
                  stroke="rgba(255, 255, 255, 0.6)"
                  strokeWidth="2"
                />

                {/* Molecule 2 - Orange and Cyan */}
                <circle cx="220" cy="180" r="7" fill="#ff6b35" opacity="0.9" />
                <circle cx="235" cy="180" r="7" fill="#00d4ff" opacity="0.9" />
                <line
                  x1="227"
                  y1="180"
                  x2="228"
                  y2="180"
                  stroke="rgba(255, 255, 255, 0.6)"
                  strokeWidth="2"
                />

                {/* Molecule 3 - Purple and Orange */}
                <circle cx="150" cy="240" r="7" fill="#7c3aed" opacity="0.9" />
                <circle cx="165" cy="240" r="7" fill="#ff6b35" opacity="0.9" />
                <line
                  x1="157"
                  y1="240"
                  x2="158"
                  y2="240"
                  stroke="rgba(255, 255, 255, 0.6)"
                  strokeWidth="2"
                />
              </>
            )}

            {/* Reaction particles - more dispersed */}
            {particles.map((p) => (
              <circle
                key={p.id}
                cx={p.x}
                cy={p.y}
                r={p.size}
                fill={p.color}
                opacity="0.85"
              />
            ))}

            {/* Energy release indicator - larger and more visible */}
            {isReacting && (
              <>
                <circle
                  cx="150"
                  cy="150"
                  r={20 + (100 - energy) * 0.5}
                  fill="none"
                  stroke="#ff6b35"
                  strokeWidth="2"
                  opacity={energy / 100}
                />
                <circle
                  cx="150"
                  cy="150"
                  r={10 + (100 - energy) * 0.3}
                  fill="none"
                  stroke="#ff6b35"
                  strokeWidth="1"
                  opacity={energy / 150}
                />
                <text
                  x="150"
                  y="160"
                  textAnchor="middle"
                  fill="#ff6b35"
                  fontSize="20"
                  fontWeight="bold"
                  opacity={energy / 100}
                >
                  ⚡
                </text>
              </>
            )}
          </svg>
        </div>

        {/* Energy meter */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-semibold text-foreground">
              Ялгарсан энерги
            </label>
            <span className="text-orange-400 font-mono font-bold">
              {energy.toFixed(0)}%
            </span>
          </div>
          <div className="w-full bg-background/50 rounded-full h-3 border border-cyan-500/20 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-purple-500 to-orange-500 transition-all duration-100"
              style={{ width: `${energy}%` }}
            />
          </div>
        </div>

        {/* Control buttons */}
        <div className="flex gap-3">
          <Button
            onClick={handleReaction}
            disabled={isReacting}
            className="flex-1 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:opacity-50 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
          >
            <Zap className="w-4 h-4" />
            Урвал эхлүүлэх
          </Button>
          <Button
            onClick={handleReset}
            className="flex-1 bg-gradient-to-r from-cyan-500 to-cyan-600 hover:from-cyan-600 hover:to-cyan-700 text-white font-semibold py-2 rounded-lg transition-all duration-300 flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Дахин эхлүүлэх
          </Button>
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-background/50 rounded-lg border border-cyan-500/10">
          <p className="text-sm text-muted-foreground">
            <span className="text-cyan-300 font-semibold">Химийн урвал</span> нь атомуудын хоорондох бонд тасрагдаж, шинэ бонд үүсэх үйл явц юм. 
            <span className="text-orange-300 font-semibold"> Энергийн хэмжүүр</span> нь урвалын үед ялгарсан энергийг харуулдаг. 
            Өөр өөр урвалууд өөр өөр хэмжээний энерги ялгаруулдаг. Хэсгүүд бүх чиглэлд тарсан байдлаар сарниж явдаг.
          </p>
        </div>
      </Card>
    </div>
  );
}
