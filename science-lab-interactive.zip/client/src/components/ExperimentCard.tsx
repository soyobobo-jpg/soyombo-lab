import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface ExperimentCardProps {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  difficulty?: "beginner" | "intermediate" | "advanced";
  image?: string;
}

export default function ExperimentCard({
  id,
  title,
  description,
  icon,
  difficulty = "beginner",
  image,
}: ExperimentCardProps) {
  const difficultyColors = {
    beginner: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
    intermediate: "bg-purple-500/20 text-purple-300 border-purple-500/30",
    advanced: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  };

  return (
    <Link href={`/experiment/${id}`}>
      <Card className="group relative overflow-hidden cursor-pointer transition-all duration-300 hover:shadow-2xl hover:shadow-cyan-500/20 border-cyan-500/20 bg-card/50 backdrop-blur-sm hover:bg-card/80 h-full">
        {/* Background image with overlay */}
        {image && (
          <div className="absolute inset-0 opacity-30 group-hover:opacity-50 transition-opacity duration-300">
            <img
              src={image}
              alt={title}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        {/* Content */}
        <div className="relative p-6 flex flex-col h-full">
          {/* Icon */}
          <div className="mb-4 text-4xl text-cyan-400 group-hover:text-cyan-300 transition-colors">
            {icon}
          </div>

          {/* Title */}
          <h3 className="text-xl font-display font-bold text-foreground mb-2 group-hover:text-cyan-300 transition-colors">
            {title}
          </h3>

          {/* Description */}
          <p className="text-sm text-muted-foreground mb-4 flex-grow">
            {description}
          </p>

          {/* Arrow button */}
          <div className="flex items-center justify-end">
            <ArrowRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Glow effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/10 via-transparent to-purple-500/10" />
        </div>
      </Card>
    </Link>
  );
}
